<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'dao', NULL, 'ao', NULL, 'xi', 'fu', 'dan', 'jiu', 'run', 'tong', 'qu', 'e', 'qi', 'ji', 'ji', 'hua',
  0x10 => 'jiao', 'zui', 'biao', 'meng', 'bai', 'wei', 'yi', 'ao', 'yu', 'hao', 'dui', 'wo', 'ni', 'cuan', NULL, 'li',
  0x20 => 'lu', 'niao', 'huai', 'li', NULL, 'lu', 'feng', 'mi', 'yu', NULL, 'ju', NULL, NULL, 'zhan', 'peng', 'yi',
  0x30 => NULL, 'ji', 'bi', NULL, 'ren', 'huang', 'fan', 'ge', 'ku', 'jie', 'sha', NULL, 'si', 'tong', 'yuan', 'zi',
  0x40 => 'bi', 'kua', 'li', 'huang', 'xun', 'nuo', NULL, 'zhe', 'wen', 'xian', 'qia', 'ye', 'mao', NULL, NULL, 'shu',
  0x50 => NULL, 'qiao', 'zhun', 'kun', 'wu', 'ying', 'chuang', 'ti', 'lian', 'bi', 'gou', 'mang', 'xie', 'feng', 'lou', 'zao',
  0x60 => 'zheng', 'chu', 'man', 'long', NULL, 'yin', 'pin', 'zheng', 'jian', 'luan', 'nie', 'yi', NULL, 'ji', 'ji', 'zhai',
  0x70 => 'yu', 'jiu', 'huan', 'zhi', 'la', 'ling', 'zhi', 'ben', 'zha', 'ju', 'dan', 'liao', 'yi', 'zhao', 'xian', 'chi',
  0x80 => 'ci', 'chi', 'yan', 'lang', 'dou', 'long', 'chan', NULL, 'tui', 'cha', 'ai', 'chi', NULL, 'ying', 'zhe', 'tou',
  0x90 => NULL, 'tui', 'cha', 'yao', 'zong', NULL, 'pan', 'qiao', 'lian', 'qin', 'lu', 'yan', 'kang', 'su', 'yi', 'chan',
  0xA0 => 'jiong', 'jiang', NULL, 'jing', NULL, 'dong', NULL, 'juan', 'han', 'di', NULL, NULL, 'hong', NULL, 'chi', 'diao',
  0xB0 => 'bi', NULL, 'xun', 'lu', NULL, 'xie', 'bi', NULL, 'bi', NULL, 'xian', 'rui', 'bie', 'er', 'juan', NULL,
  0xC0 => 'zhen', 'bei', 'e', 'yu', 'qu', 'zan', 'mi', 'yi', 'si', NULL, NULL, NULL, 'shan', 'tai', 'mu', 'jing',
  0xD0 => 'bian', 'rong', 'ceng', 'can', 'ding', NULL, NULL, NULL, NULL, 'di', 'tong', 'ta', 'xing', 'song', 'duo', 'xi',
  0xE0 => 'tao', NULL, 'ti', 'shan', 'jian', 'zhi', 'wei', 'yin', NULL, NULL, 'huan', 'zhong', 'qi', 'zong', NULL, 'xie',
  0xF0 => 'xie', 'ze', 'wei', NULL, NULL, 'ta', 'zhan', 'ning', NULL, NULL, NULL, 'yi', 'ren', 'shu', 'cha', 'zhuo',
];
